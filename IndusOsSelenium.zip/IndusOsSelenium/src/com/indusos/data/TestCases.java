package com.indusos.data;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.indusos.base.GetDriver;


public class TestCases {
	
	
	public void amazonTest() throws InterruptedException {

		GetDriver.driver.get("https://www.amazon.in/");
		GetDriver.driver.manage().window().maximize();
		
		GetDriver.driver.findElement(By.id("nav-link-yourAccount")).click();
		GetDriver.driver.findElement(By.id("ap_email")).sendKeys(SeleContant.userName);
		GetDriver.driver.findElement(By.id("continue")).click();
		GetDriver.driver.findElement(By.id("ap_password")).sendKeys(SeleContant.Password);
		GetDriver.driver.findElement(By.id("signInSubmit")).click();
		
		GetDriver.driver.findElement(By.id("twotabsearchtextbox")).sendKeys("redmi note");
		GetDriver.driver.findElement(By.xpath("//*[@id=\"nav-search\"]/form/div[2]/div/input")).click();
		
		
		WebElement element = GetDriver.driver.findElement(By.partialLinkText("Redmi Y2"));
		
		 Actions actions = new Actions(GetDriver.driver);
		 actions.moveToElement(element);
		 actions.perform();
		 element.click();
	
		// Switch to new window opened
		for(String winHandle : GetDriver.driver.getWindowHandles()){
			GetDriver.driver.switchTo().window(winHandle);
		}
		Thread.sleep(5000);
		WebElement ele = GetDriver.driver.findElement(By.id("maxBuyBackDiscountSection"));
		ele.click();
		Thread.sleep(3000);
		WebElement elem = GetDriver.driver.findElement(By.xpath("//*[@id='newAccordionRow']/div/div[1]"));
		elem.click();
		 GetDriver.driver.findElement(By.id("add-to-cart-button")).click();;
		 GetDriver.driver.findElement(By.id("hlb-view-cart-announce")).click();;
		 WebElement confirmText = GetDriver.driver.findElement(By.partialLinkText("Redmi Y2"));
		 if(confirmText.isDisplayed()){
			 System.out.println("found in cart");
			 assertTrue(true);
		 }
		
		 
		
		 
		
	}	
	
	
	
}
