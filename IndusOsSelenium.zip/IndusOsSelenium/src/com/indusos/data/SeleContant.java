package com.indusos.data;

public class SeleContant {

	public static final String userName = "";
	public static final String Password = "";
}
