package com.indusos.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.indusos.data.TestCases;


public class App {

	
	WebDriver driver;
	TestCases test = new TestCases();

	@BeforeTest
	public void setup() {
		System.setProperty("webdriver.chrome.driver",
				"F:\\chrome\\chromedriver.exe");
		GetDriver.driver = new ChromeDriver();

		GetDriver.driver.manage().timeouts()
				.implicitlyWait(20, TimeUnit.SECONDS);

	}

	@Test(priority = 1)
	public void amazon() {

		try {
			test.amazonTest();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}


	@AfterTest
	public void end() {
		GetDriver.driver.quit();
	}
	
}
