package com.indusos.base;

import org.openqa.selenium.WebDriver;

public class GetDriver {

	public static WebDriver driver;
	
}
