package com.indusos.main;


import static org.testng.Assert.assertTrue;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class App {

	
	
	@DataProvider(name = "searchName")
	 
	  public static Object[][] credentials() {
	 
	        return new Object[][] { { "Nvidia", 20 }};
	 
	  }

	@Test(dataProvider = "searchName")
	public void getApi(String key,int count) {
		 try {
		// Specify the base URL to the RESTful web service
		URL url = new URL("https://newsapi.org/v2/top-headlines?country=us&apiKey=40889ba2baae4b609c708400548ae4cc");
		 
		 RequestSpecification httpRequest = RestAssured.given();
		 
		 
		 Response response = httpRequest.request(Method.GET, url);
		 
		 String responseBody = response.getBody().asString();
		 System.out.println("Response Body is =>  " + responseBody);
		 System.out.println("key "+key);
		 System.out.println("count "+count);
		 
		 JSONObject jsonObject = new JSONObject(responseBody);
		 System.out.println("jsonObject "+jsonObject);
		 JSONArray jsonObject1 = (JSONArray) jsonObject.get("articles");
		 System.out.println("jsonObject1 "+jsonObject1);
		 
		 ArrayList<String> list = new ArrayList<String>();
		 System.out.println("=================headline title are ====================");
		 for(int i=0; i<jsonObject1.length(); i++){
			    list.add(jsonObject1.getJSONObject(i).getString("title"));
			    
			    System.out.println("headline"+": "+jsonObject1.getJSONObject(i).getString("title"));
			}
		 System.out.println("================= ====================");
		 System.out.println("");
		 boolean flag = false;
		 for(int i=0;i<count;i++){
			 if(list.get(i).contains(key)){
				 flag =true;
				 System.out.println("================= RESULT ====================");
				
				 System.out.println("match found at headline number "+i); 
				 
				 System.out.println("=================  ====================");
				 System.out.println("");
				 
			 }
		 }
		 if(flag==false){
			 System.out.println("================= RESULT ====================");
			 
			 System.out.println("match not found ");
			 
			 System.out.println("================= ====================");
			 System.out.println("");
		 }
		 assertTrue(flag);
			
			
		} catch (Exception e) {
			System.out.println("Exception "+e);
		}

	}
	
}
